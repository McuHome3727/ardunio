# LMV2596 5V Buck Converter

5V Buck Converter based on the [LM2596](https://www.ti.com/lit/gpn/lm2596).

![IMG_20200111_160419_x.jpg](https://image.easyeda.com/pullimage/u7gXdgO6U9UGPXfZC9cimWuZ6az31SlvdAqcG5HZ.jpeg)
![LM2596_efficiency_x.png](https://image.easyeda.com/pullimage/rP6zqIzWsEZ4TiFKpl9byqj6Gyi20itlbBWZYFjT.png)
