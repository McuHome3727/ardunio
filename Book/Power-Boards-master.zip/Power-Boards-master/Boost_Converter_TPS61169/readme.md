# TPS61169 Boost LED Driver Stick

Constant current boost converter and LED Driver with USB Plug based on [TPS61169](https://datasheet.lcsc.com/szlcsc/1810292010_Texas-Instruments-TPS61169DCKR_C71045.pdf).

![IMG_20200315_151415_x.jpg](https://image.easyeda.com/pullimage/hsKdiqPm0A75mJzs1EiWkaLzdW4FENb6iK2JoRHU.jpeg)
