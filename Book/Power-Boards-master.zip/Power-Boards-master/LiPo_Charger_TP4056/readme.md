# TP4056 LiPo Charger

LiPo battery charging ([TP4056](https://datasheet.lcsc.com/szlcsc/1904031009_TPOWER-TP4056_C382139.pdf)) and protection ([DW01A](https://datasheet.lcsc.com/szlcsc/1901091236_PUOLOP-DW01A_C351410.pdf)) circuit.

![LiPoCharger.jpg](https://image.easyeda.com/pullimage/1AFRDXL18TS9FlEvhszar0sCkHfKe3Lg5W7eNZ97.jpeg)
