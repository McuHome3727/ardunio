# MT3608 12V Boost Converter Stick

USB plug with 12V boost converter based on [MT3608](https://datasheet.lcsc.com/szlcsc/XI-AN-Aerosemi-Tech-MT3608_C84817.pdf).

![IMG_20200112_124304_x.jpg](https://image.easyeda.com/pullimage/K8Bdxui2yqWwZzSk6TuPmTPbPUSVSljN5FRV8h00.jpeg)
