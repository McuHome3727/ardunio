# LIR1220 Charger

Charger for [LIR1220](https://www.macrogroup.ru/sites/default/files/uploads/lir1220.pdf) Li-Ion batteries based on [MCP73831](https://datasheet.lcsc.com/szlcsc/1809191822_Microchip-Tech-MCP73831T-2ATI-OT_C14879.pdf).

![pic1.jpg](https://raw.githubusercontent.com/wagiminator/Power-Boards/master/LIR1220_Charger_MCP73831/LIR1220_Charger_MCP73831_pic1.jpg)
![pic2.jpg](https://raw.githubusercontent.com/wagiminator/Power-Boards/master/LIR1220_Charger_MCP73831/LIR1220_Charger_MCP73831_pic2.jpg)
![pic3.jpg](https://raw.githubusercontent.com/wagiminator/Power-Boards/master/LIR1220_Charger_MCP73831/LIR1220_Charger_MCP73831_pic3.jpg)
