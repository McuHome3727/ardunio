# MP2307 5V Buck Converter

5V buck converter based on [MP2307](https://cdn-shop.adafruit.com/datasheets/MP2307_r1.9.pdf).

![IMG_20190726_133342.jpg](https://image.easyeda.com/pullimage/rahd7Wc1zkiYGPVX175igG8T43oeKwF9p2yL1J9w.jpeg)
![MP2307_efficiency_x.png](https://image.easyeda.com/pullimage/8iQdtMDXOFC47ZdzBdaSCOZiYrPsqTUXzecqmbeK.png)
