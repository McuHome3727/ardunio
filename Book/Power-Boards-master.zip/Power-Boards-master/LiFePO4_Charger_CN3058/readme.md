# CN3058 LiFePO4 Battery Charger

One cell LiFePO4 battery charger ([CN3058E](https://datasheet.lcsc.com/szlcsc/ShangHai-Consonance-Elec-CN3058E_C112011.pdf)) and protector ([HY2112](https://datasheet.lcsc.com/szlcsc/1810010241_HYCON-Tech-HY2112-BB_C161942.pdf)).

![IMG_20190721_164209.jpg](https://image.easyeda.com/pullimage/4ykMOFt3d5ls7DusMjOq662KOYd00YjNfU30758B.jpeg)
