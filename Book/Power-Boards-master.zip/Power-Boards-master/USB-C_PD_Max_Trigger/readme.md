# USB-C PD Max Power Trigger Board

Very simple USB-C Power Delivery trigger board based on the [IP2721](https://datasheet.lcsc.com/szlcsc/2006111335_INJOINIC-IP2721_C603176.pdf) that requests the maximum voltage (up to 20V) from the power supply.

![IMG_20200712_130242_x.jpg](https://image.easyeda.com/pullimage/KhicZ02sJj8aRwT7HONIKgJYQr7za6HGb05xTSOy.jpeg)
