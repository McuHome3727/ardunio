LIR2032 Charger

Charger for [LIR2032](https://www.powerstream.com/p/Lir2032.pdf) Li-Ion batteries based on [TP4056](https://datasheet.lcsc.com/szlcsc/1904031009_TPOWER-TP4056_C382139.pdf).

![IMG_20200111_160350_x.jpg](https://image.easyeda.com/pullimage/EShLyzT9JReVfZoNtx9tAFyMHE65saIXZoaC6Sfo.jpeg)
