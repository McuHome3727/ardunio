Charger for LIR2032 Li-Ion batteries.
